const onHeadersReceived = function (details) {
	for (let i = 0; i < details.responseHeaders.length; i++)
		if (details.responseHeaders[i].name.toLowerCase() === "content-security-policy")
			details.responseHeaders[i].value = ""

	chrome.tabs.executeScript({
		code: 'localStorage.setItem("retube-extension-installed", true);'
	});
	return {
		responseHeaders: details.responseHeaders,
	}
}

const filter = {
	urls: ["*://*/*"],
	types: ["main_frame", "sub_frame"],
}

chrome.webRequest.onHeadersReceived.addListener(onHeadersReceived, filter, [
	"blocking",
	"responseHeaders",
])